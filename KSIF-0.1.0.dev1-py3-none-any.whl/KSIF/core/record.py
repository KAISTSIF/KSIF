"""

"""
import os


def curpath():
    pth, _ = os.path.split(os.path.abspath(__file__))
    return pth

__author__ = 'Seung Hyeon Yu'
__email__ = 'rambor12@business.kaist.ac.kr'